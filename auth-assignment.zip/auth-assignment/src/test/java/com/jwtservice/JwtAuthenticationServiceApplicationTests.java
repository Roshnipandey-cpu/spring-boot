package com.jwtservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JwtAuthenticationServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
